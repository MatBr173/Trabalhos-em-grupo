using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;
using System.Drawing.Printing;

namespace ConversorArquivosSimples
{
    public partial class Form1 : Form
    {
        private string arquivoSelecionado = ""; // Armazena o caminho do arquivo selecionado
        private string conteudoTxt = "";         // Armazena o conteúdo do arquivo TXT carregado

        public Form1()
        {
            InitializeComponent();

            // Adiciona opções de conversão ao ComboBox quando o formulário é iniciado
            string[] opcoes = {
                "TXT para PDF (simulado)",
                "TXT para HTML",
                "TXT para UPPERCASE",
                "JPG para PNG",
                "BMP para JPG",
                "PNG para BMP"
            };
            cmbTipoConversao.Items.AddRange(opcoes);
            cmbTipoConversao.SelectedIndex = 0; // Seleciona a primeira opção como padrão
        }

        // Evento chamado quando o botão "Selecionar" é clicado
        private void btnSelecionar_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    arquivoSelecionado = dialog.FileName; // Salva o caminho do arquivo selecionado
                    lblArquivo.Text = arquivoSelecionado; // Exibe o caminho no label

                    // Se for um arquivo TXT, carrega o conteúdo para memória
                    if (arquivoSelecionado.EndsWith(".txt", StringComparison.OrdinalIgnoreCase))
                    {
                        conteudoTxt = File.ReadAllText(arquivoSelecionado);
                    }
                }
            }
        }

        // Evento chamado quando o botão "Converter" é clicado
        private void btnConverter_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(arquivoSelecionado))
            {
                MessageBox.Show("Selecione um arquivo primeiro.");
                return;
            }

            string tipo = cmbTipoConversao.SelectedItem.ToString(); // Pega o tipo de conversão selecionado

            // Verifica se o tipo do arquivo é compatível com a conversão escolhida
            if (!VerificarCompatibilidade(arquivoSelecionado, tipo))
            {
                MessageBox.Show("O tipo do arquivo selecionado não é compatível com a conversão escolhida.");
                return;
            }

            try
            {
                // Realiza a conversão conforme o tipo selecionado
                switch (tipo)
                {
                    case "TXT para PDF (simulado)":
                        ConverterTxtParaPdfSimples();
                        break;
                    case "TXT para HTML":
                        ConverterTxtParaHtml();
                        break;
                    case "TXT para UPPERCASE":
                        ConverterTxtParaUpper();
                        break;
                    case "JPG para PNG":
                        ConverterImagem(ImageFormat.Png);
                        break;
                    case "BMP para JPG":
                        ConverterImagem(ImageFormat.Jpeg);
                        break;
                    case "PNG para BMP":
                        ConverterImagem(ImageFormat.Bmp);
                        break;
                }

                MessageBox.Show("Arquivo convertido com sucesso!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.Message);
            }
        }

        // Verifica se o tipo do arquivo é compatível com a conversão selecionada
        private bool VerificarCompatibilidade(string caminhoArquivo, string tipoConversao)
        {
            string extensao = Path.GetExtension(caminhoArquivo).ToLower();

            switch (tipoConversao)
            {
                case "TXT para PDF (simulado)":
                case "TXT para HTML":
                case "TXT para UPPERCASE":
                    return extensao == ".txt";

                case "JPG para PNG":
                    return extensao == ".jpg" || extensao == ".jpeg";

                case "PNG para BMP":
                    return extensao == ".png";

                case "BMP para JPG":
                    return extensao == ".bmp";

                default:
                    return false;
            }
        }

        // Simula a conversão de um arquivo TXT para PDF usando impressão
        private void ConverterTxtParaPdfSimples()
        {
            PrintDocument pd = new PrintDocument();
            pd.PrintPage += (sender, args) =>
            {
                // Desenha o conteúdo do TXT como texto na folha a ser impressa
                args.Graphics.DrawString(conteudoTxt, new Font("Arial", 12), Brushes.Black, new PointF(100, 100));
            };
            PrintDialog printDialog = new PrintDialog
            {
                Document = pd
            };
            if (printDialog.ShowDialog() == DialogResult.OK)
            {
                pd.Print(); // Envia para impressora se o usuário confirmar
            }
        }

        // Converte um arquivo TXT em um arquivo HTML, formatando o conteúdo como pré-formatado
        private void ConverterTxtParaHtml()
        {
            string html = $"<html><body><pre>{conteudoTxt}</pre></body></html>";
            string caminho = Path.ChangeExtension(arquivoSelecionado, ".html"); // Muda extensão para .html
            File.WriteAllText(caminho, html); // Salva o novo arquivo
        }

        // Converte o conteúdo de um TXT para letras maiúsculas e salva em novo arquivo
        private void ConverterTxtParaUpper()
        {
            string upper = conteudoTxt.ToUpper();
            string caminho = Path.ChangeExtension(arquivoSelecionado, ".upper.txt"); // Nova extensão .upper.txt
            File.WriteAllText(caminho, upper);
        }

        // Converte uma imagem para o formato especificado (PNG, JPG, BMP)
        private void ConverterImagem(ImageFormat formato)
        {
            using (Image imagem = Image.FromFile(arquivoSelecionado))
            {
                string novaExtensao = formato.ToString().ToLower(); // Obtém a extensão baseada no formato
                string novoCaminho = Path.ChangeExtension(arquivoSelecionado, novaExtensao); // Novo caminho de salvamento
                imagem.Save(novoCaminho, formato); // Salva a imagem no novo formato
            }
        }
    }
}
