namespace ConversorArquivosSimples
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.btnSelecionar = new System.Windows.Forms.Button();
            this.cmbTipoConversao = new System.Windows.Forms.ComboBox();
            this.btnConverter = new System.Windows.Forms.Button();
            this.lblArquivo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnSelecionar
            // 
            this.btnSelecionar.Location = new System.Drawing.Point(12, 12);
            this.btnSelecionar.Name = "btnSelecionar";
            this.btnSelecionar.Size = new System.Drawing.Size(120, 23);
            this.btnSelecionar.TabIndex = 0;
            this.btnSelecionar.Text = "Selecionar Arquivo";
            this.btnSelecionar.UseVisualStyleBackColor = true;
            this.btnSelecionar.Click += new System.EventHandler(this.btnSelecionar_Click);
            // 
            // cmbTipoConversao
            // 
            this.cmbTipoConversao.FormattingEnabled = true;
            this.cmbTipoConversao.Location = new System.Drawing.Point(138, 14);
            this.cmbTipoConversao.Name = "cmbTipoConversao";
            this.cmbTipoConversao.Size = new System.Drawing.Size(160, 21);
            this.cmbTipoConversao.TabIndex = 1;
            // 
            // btnConverter
            // 
            this.btnConverter.Location = new System.Drawing.Point(304, 12);
            this.btnConverter.Name = "btnConverter";
            this.btnConverter.Size = new System.Drawing.Size(75, 23);
            this.btnConverter.TabIndex = 2;
            this.btnConverter.Text = "Converter";
            this.btnConverter.UseVisualStyleBackColor = true;
            this.btnConverter.Click += new System.EventHandler(this.btnConverter_Click);
            // 
            // lblArquivo
            // 
            this.lblArquivo.AutoSize = true;
            this.lblArquivo.Location = new System.Drawing.Point(12, 50);
            this.lblArquivo.Name = "lblArquivo";
            this.lblArquivo.Size = new System.Drawing.Size(138, 13);
            this.lblArquivo.TabIndex = 3;
            this.lblArquivo.Text = "Nenhum arquivo selecionado";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(391, 80);
            this.Controls.Add(this.lblArquivo);
            this.Controls.Add(this.btnConverter);
            this.Controls.Add(this.cmbTipoConversao);
            this.Controls.Add(this.btnSelecionar);
            this.Name = "Form1";
            this.Text = "Conversor de Arquivos Simples";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Button btnSelecionar;
        private System.Windows.Forms.ComboBox cmbTipoConversao;
        private System.Windows.Forms.Button btnConverter;
        private System.Windows.Forms.Label lblArquivo;
    }
}